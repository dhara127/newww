import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Todo } from 'src/app/shared/models/task.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-todo-view',
  templateUrl: './todo-view.component.html',
  styleUrls: ['./todo-view.component.scss']
})
export class TodoViewComponent implements OnInit {
  todoData: Todo;
  todoId: number;
  
  constructor(    
    private todoService: TodoService,
    private router:Router,
    private activatedRoute:ActivatedRoute,
    private sharedService: SharedService
    ) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params:any) => {
      this.todoId = params.id;
      this.getTodoData(this.todoId)
    }); 
  }
  /**
   * Get the todo task by ID
   */
  getTodoData(id) {
    this.todoService.getToDo(id).subscribe(result => {
      this.todoData = result;
    },
      error => {
        this.sharedService.openSnackBar("Unable to fetch Todo task").afterDismissed().subscribe(() => {
        });      
      });
  }

}
