import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { Todo } from '../shared/models/task.model';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  selectedhost: string = "";
  errorRedirectHeader: HttpHeaders;

  public baseUrl = environment.apiUrl + 'tasks/';

  constructor(private http: HttpClient) { 
  }

  getAllToDO(): Observable<Array<Todo>> {
    return this.http.get<Array<Todo>>(this.baseUrl);
  }

  getToDo(id: number):Observable<Todo>  {
    return this.http.get<Todo>(this.baseUrl + '/' + id)
  }

  deleteToDo(id: number):Observable<Todo>  {
    return this.http.delete<Todo>(this.baseUrl + '/' + id)
  }

  updateToDo(todo: Todo):Observable<Todo>   {
    return this.http.patch<Todo>(this.baseUrl + '/' + todo.id, todo);
  }

  addToDo(todo: Todo):Observable<Todo>{
    return this.http.post<Todo>(this.baseUrl + '/', todo);
  }

}
