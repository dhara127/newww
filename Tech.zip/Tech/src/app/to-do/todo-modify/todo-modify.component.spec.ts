import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SharedService } from 'src/app/shared/services/shared.service';
import { TodoService } from '../todo.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing'

import { TodoModifyComponent } from './todo-modify.component';
import { Todo } from 'src/app/shared/models/task.model';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('TodoModifyComponent', () => {
  let todoService : TodoService;
  let sharedService : SharedService;
  //let httpClient : HttpClient
  let httpTestController : HttpTestingController
  let component: TodoModifyComponent;
  let fixture: ComponentFixture<TodoModifyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TodoModifyComponent ],
      imports:[HttpClientTestingModule],
      providers: [TodoService, SharedService],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    })
    todoService = TestBed.inject(TodoService);
    sharedService = TestBed.inject(SharedService);
  });

  beforeEach(() => {
    todoService = TestBed.inject(TodoService);
    sharedService = TestBed.inject(SharedService);
    httpTestController = TestBed.inject(HttpTestingController);
  });

});
