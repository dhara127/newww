import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TodoService } from '../todo.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { Todo } from 'src/app/shared/models/task.model';
import * as moment from 'moment'
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-todo-modify',
  templateUrl: './todo-modify.component.html',
  styleUrls: ['./todo-modify.component.scss']
})
export class TodoModifyComponent implements OnInit {

  todoFormGroup: FormGroup;
  todoData: Todo;
  todoId: number;
  mode: string;

  constructor(
    private todoService: TodoService,
    private router:Router,
    private activatedRoute:ActivatedRoute, 
    fb: FormBuilder,
    private sharedService: SharedService
    ) {
      this.todoFormGroup = fb.group({
        label: ['', Validators.required],
        description: ['', Validators.required],
        category: ['', Validators.required],
        done: [''],
    });
  }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((params:any) => {
      this.todoId = params.id;
      this.mode = this.todoId ? 'edit' : 'add';
      if(this.mode == 'edit'){
        this.getTodoData(this.todoId)
      }
    }); 
  }
  /**
   * Get the todo task by ID
   */
  getTodoData(id) {
    this.todoService.getToDo(id).subscribe(result => {
      this.todoData = result;
      this.setTodoValues();
    },
      error => {
        this.sharedService.openSnackBar("Unable to fetch Todo task").afterDismissed().subscribe(() => {
        });      
      });
  }

  setTodoValues(){
    this.todoFormGroup.get('label').setValue(this.todoData.label);
    this.todoFormGroup.get('description').setValue(this.todoData.description);
    this.todoFormGroup.get('category').setValue(this.todoData.category);
    this.todoFormGroup.get('done').setValue(this.todoData.done);
  }

  /**
   * Update the task and return to the list
   */
   updateTodo() {
    const todo = {
      id: this.todoId,
      label : this.todoFormGroup.get('label').value,
      description : this.todoFormGroup.get('description').value,
      category : this.todoFormGroup.get('category').value,
      done : this.todoFormGroup.get('done').value === true ?  moment().format('MM-DD-YYYY') : false
    }
    this.todoService.updateToDo(todo).subscribe(result => {
      this.todoData = result;
      this.sharedService.openSnackBar("ToDo Task Updated").afterDismissed().subscribe(() => {
        this.router.navigate([''],{relativeTo:this.activatedRoute});
      });
      },
    error => {
      this.sharedService.openSnackBar("Unable to Update Todo task").afterDismissed().subscribe(() => {
      });
    });
  }

  /**
   * Adding the task and return to the list
   */
  addTodo(){
    const todo = {
      label : this.todoFormGroup.get('label').value,
      description : this.todoFormGroup.get('description').value,
      category : this.todoFormGroup.get('category').value,
      done : this.todoFormGroup.get('done').value === true ?  moment().format('MM-DD-YYYY') : false
    }
    this.todoService.addToDo(todo).subscribe(result => {
      this.todoData = result;
      this.sharedService.openSnackBar("ToDo Task Added").afterDismissed().subscribe(() => {
        this.router.navigate([''],{relativeTo:this.activatedRoute});
      });
    },
    error => {
      this.sharedService.openSnackBar("Unable to Add Todo task").afterDismissed().subscribe(() => {
      });    
    });
  }

}
