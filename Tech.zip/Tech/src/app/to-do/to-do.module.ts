import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ToDoRoutingModule } from './to-do-routing.module';
import { TodoListComponent } from './todo-list/todo-list.component';
import { TodoViewComponent } from './todo-view/todo-view.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TodoModifyComponent } from './todo-modify/todo-modify.component';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [
    TodoListComponent,
    TodoViewComponent,
    TodoModifyComponent
  ],
  imports: [
    CommonModule,
    ToDoRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class ToDoModule { }
