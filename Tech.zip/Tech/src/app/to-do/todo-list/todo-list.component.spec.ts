import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TodoListComponent } from './todo-list.component';
import { SharedService } from 'src/app/shared/services/shared.service';
import { TodoService } from '../todo.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing'

import { Todo } from 'src/app/shared/models/task.model';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('TodoListComponent', () => {
  let component: TodoListComponent;
  let fixture: ComponentFixture<TodoListComponent>;
  let todoService : TodoService;
  let sharedService : SharedService;
  //let httpClient : HttpClient
  let httpTestController : HttpTestingController

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TodoListComponent ],
      imports:[HttpClientTestingModule],
      providers: [TodoService, SharedService],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TodoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  
});
