import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Todo } from 'src/app/shared/models/task.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { TodoService } from '../todo.service';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.scss']
})
export class TodoListComponent implements OnInit {

  searchText: string;
  title = 'tech-test';
  toDoDetails: Array<Todo>;

  constructor(private todoService: TodoService,
    private router:Router,
    private activatedRoute:ActivatedRoute,
    private sharedService: SharedService
    ) {
  }

  ngOnInit() : void{
    this.getTodoDetails();
  }

  getTodoDetails() {
    this.todoService.getAllToDO().subscribe(result => {
      this.toDoDetails = result;
    },
      error => {
        this.sharedService.openSnackBar("Unable to fetch Todo task").afterDismissed().subscribe(() => {
        });        
      });
  }


  delete(id): void {
    this.todoService.deleteToDo(id).subscribe(result => {
      this.sharedService.openSnackBar("ToDO Task Deleted").afterDismissed().subscribe(() => {
        this.getTodoDetails();
      });  
    },
      error => {
        this.sharedService.openSnackBar("Unable to Delete Todo task").afterDismissed().subscribe(() => {
        });   
      });
  }

  add(): void {
    this.router.navigate(['todo-add'], {relativeTo: this.activatedRoute});
  }

  edit(id){
  this.router.navigate(['todo-edit', id], {relativeTo: this.activatedRoute});
  }

  view(id){
    this.router.navigate(['todo-view', id], {relativeTo: this.activatedRoute});
  }

}
