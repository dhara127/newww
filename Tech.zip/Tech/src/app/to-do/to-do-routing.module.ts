import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TodoListComponent } from './todo-list/todo-list.component';
import { TodoModifyComponent } from './todo-modify/todo-modify.component';
import { TodoViewComponent } from './todo-view/todo-view.component';

const routes: Routes = [
  {
    path: '',
    component: TodoListComponent,
  },
  {
    path: 'todo-view/:id',
    component: TodoViewComponent,
  },
  {
    path: 'todo-add',
    component: TodoModifyComponent,
  },
  {
    path: 'todo-edit/:id',
    component: TodoModifyComponent,
  }
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ToDoRoutingModule { }
