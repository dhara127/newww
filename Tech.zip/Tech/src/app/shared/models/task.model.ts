export class Todo {
  id?: number;
  label: string;
  description: string;
  category: string;
  done: boolean | string;
}
